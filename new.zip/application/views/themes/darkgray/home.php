<?php if ($page['description'] != ""): ?>
    <?php echo $page['description']; ?>
<?php endif; ?>