
<div class="content-wrapper" >
    
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-primary">
                    <div class="box-body" style="min-height:686px">
                        <div class="alert alert-danger alert-dismissible mb0">
                            <?php echo $this->lang->line('please_select_any_one_paymentgateway'); ?>
                        </div>
                    </div>    
                </div>    
            </div>    
        </div>
    </section>
    <div class="clearfix"></div>
</div>
