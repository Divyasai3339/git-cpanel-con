
<div class="content-wrapper" style="min-height: 1126px;">
    <section class="content-header">
        <h1>
            <i class="fa fa-money"></i> <?php echo $this->lang->line('payment'); ?>
        </h1>
    </section>
    <!-- Main content -->
    <section class="invoice">
        <div class="row">
            <div class="alert alert-success alert-dismissible">

                <h4><i class="fa fa-check"></i> <?php echo $this->lang->line('success'); ?> </h4>
                <?php echo $this->lang->line('thank_you_for_your_payment'); ?>
            </div>
        </div>
    </section>
    <div class="clearfix"></div>
</div>
